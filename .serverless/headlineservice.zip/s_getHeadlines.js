
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jlippy',
  applicationName: 'headlineservice',
  appUid: 'w1VMj9cCCNJ6XrbN7g',
  orgUid: '44056344-8e1c-418c-b334-ba5fa4002204',
  deploymentUid: 'e52098ca-336c-4893-b827-cb29e1dc7fad',
  serviceName: 'headlineservice',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'headlineservice-dev-getHeadlines', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getHeadlines, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}