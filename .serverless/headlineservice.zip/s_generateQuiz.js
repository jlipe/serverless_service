
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jlippy',
  applicationName: 'headlineservice',
  appUid: 'w1VMj9cCCNJ6XrbN7g',
  orgUid: '44056344-8e1c-418c-b334-ba5fa4002204',
  deploymentUid: '4bad3c1d-253a-4167-b709-5d71365b61b4',
  serviceName: 'headlineservice',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'headlineservice-dev-generateQuiz', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.generateQuiz, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}